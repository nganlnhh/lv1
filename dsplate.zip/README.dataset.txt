# undefined > 2022-03-04 1:00pm
https://public.roboflow.ai/object-detection/undefined

Provided by undefined
License: CC BY 4.0

This is a U.S. license plate dataset + model using object detection. The images for this dataset were collected from Google images and around Central Florida parks. If you see your license plate in this dataset and you wish to remove it, please contact friends@roboflow.com

![white-car-with-license-plate-bounding-box-detected](https://static.slab.com/prod/uploads/5pbizn5i/posts/images/k6Waah932jRPJ9oSlOsHQ6gQ.png)


Try it out on [this example web app](https://detect.roboflow.com/?model=license-plate-recognition-lhqow&version=1&api_key=wbWI8HFrNPUg5cZGF2t1) or deploy to [Luxonis Oak ](https://docs.roboflow.com/inference/luxonis-oak). And remember, if it doesn't work so well, to make it better, you can upload and annotate new images of yourself doing rock paper scissors to futher educate the model.